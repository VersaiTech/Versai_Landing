<?php
$directory = "gallery/images/";
$images = glob($directory . "*.{jpg,png,gif,jpeg}", GLOB_BRACE);

$imageUrls = array_map(function($image) {
    return 'gallery/images/' . basename($image);
}, $images);

echo json_encode($imageUrls);
?>
